
const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Créer un ticket de support.'),
    async execute(interaction) {
        await interaction.reply({ content: 'Votre ticket a été créé. Un modérateur vous répondra bientôt.', ephemeral: true });
        const channel = await interaction.guild.channels.create({
            name: `ticket-${interaction.user.username}`,
            type: 0,
            permissionOverwrites: [
                { id: interaction.guild.id, deny: ['ViewChannel'] },
                { id: interaction.user.id, allow: ['ViewChannel', 'SendMessages'] }
            ]
        });
        await channel.send(`Bienvenue ${interaction.user}, un modérateur sera avec vous sous peu.`);
    }
};
