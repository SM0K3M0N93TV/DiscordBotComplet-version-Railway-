
const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('notiflive')
        .setDescription('Simuler une notification de live (test).'),
    async execute(interaction) {
        await interaction.reply('🔴 **LIVE EN COURS !**
Streamer : `Exemple`
Lien : https://twitch.tv/exemple');
    }
};
