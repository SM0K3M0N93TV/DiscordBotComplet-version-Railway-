
const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Bannir un utilisateur.')
        .addUserOption(option => option.setName('utilisateur').setDescription('Utilisateur à bannir').setRequired(true)),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return interaction.reply({ content: 'Permission refusée.', ephemeral: true });
        }
        const user = interaction.options.getUser('utilisateur');
        await interaction.guild.members.ban(user);
        await interaction.reply(`${user.tag} a été banni.`);
    }
};
