
const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('gstart')
        .setDescription('Lancer un giveaway.')
        .addStringOption(option => option.setName('prix').setDescription('Nom du prix').setRequired(true)),
    async execute(interaction) {
        const prix = interaction.options.getString('prix');
        const msg = await interaction.reply({ content: `🎉 **GIVEAWAY** 🎉
Prix : ${prix}
Réagis avec 🎉 pour participer !`, fetchReply: true });
        await msg.react('🎉');

        setTimeout(async () => {
            const fetchedMsg = await interaction.channel.messages.fetch(msg.id);
            const users = await fetchedMsg.reactions.cache.get('🎉').users.fetch();
            const entrants = users.filter(u => !u.bot).map(u => u);
            const winner = entrants[Math.floor(Math.random() * entrants.length)];
            interaction.followUp(`🎉 Félicitations ${winner}, tu as gagné **${prix}** !`);
        }, 60000); // 1 minute
    }
};
