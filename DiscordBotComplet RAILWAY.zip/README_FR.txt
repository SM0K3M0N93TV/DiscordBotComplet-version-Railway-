
BOT DISCORD COMPLET

Fonctionnalités incluses :
- Système de tickets
- Tracker d'invitations
- Modération complète (ban, kick, warn, mute)
- Giveaways
- Notifications de live Twitch, Kick, YouTube, Dailymotion, Snapchat

Instructions :
1. Installer Node.js 18+
2. Renommer .env.example en .env et ajouter ton TOKEN
3. Lancer avec : npm install && node index.js
